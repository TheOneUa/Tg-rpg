// ============================================================
//  VERSION
// ============================================================
const VERSION = '4.5.0';

// ============================================================
//  CONFIG
// ============================================================
const CFG = {
    TILE: 48,
    W_COLS: 13,
    W_ROWS: 13,
    D_COLS: 40,
    D_ROWS: 32,
    TOP: 58,
    BOT: 152,
    SPAWN_X: 6 * 48 + 24,
    SPAWN_Y: 6 * 48 + 24,
    PORTAL_X: 6 * 48 + 24,
    PORTAL_Y: 2 * 48 + 24,
    SAVE_INTERVAL: 5000,
    LEVEL_COST: 10
};

// ============================================================
//  TILE TYPES
// ============================================================
const T_GRASS = 0, T_TREE = 1, T_WATER = 2, T_STONE = 3, T_SAND = 4;
const T_DF = 5, T_DW = 6, T_DOOR = 7, T_ENTRANCE = 8, T_EXIT = 9;
const SOLID = new Set([T_TREE, T_WATER, T_DW]);

// ============================================================
//  CLASSES
// ============================================================
const CLASSES = {
    warrior: { name: 'Мечник', icon: '⚔️', hp: 140, mp: 40, atk: 25, def: 8, spd: 2.5 },
    mage:    { name: 'Маг',    icon: '🔮', hp: 90,  mp: 100, atk: 18, def: 3, spd: 2.2 },
    archer:  { name: 'Лучник', icon: '🏹', hp: 110, mp: 60,  atk: 22, def: 5, spd: 2.8 }
};

// ============================================================
//  SHOP
// ============================================================
const SHOP = [
    { name: 'Зелье HP', icon: '🧪', desc: '+40 HP', price: 30, give: 'hpPot' },
    { name: 'Зелье MP', icon: '💧', desc: '+30 MP', price: 25, give: 'mpPot' },
    { name: 'Меч+', icon: '⚔️', desc: '+10 атаки', price: 60, give: 'sword' },
    { name: 'Щит', icon: '🛡️', desc: '+4 защиты', price: 50, give: 'shield' }
];

// ============================================================
//  ENEMY TYPES
// ============================================================
const ENEMY_TYPES = [
    { name: 'Гоблин', hp: 40, atk: 8, exp: 20, color: '#50a03c', icon: '👹' },
    { name: 'Скелет', hp: 60, atk: 12, exp: 35, color: '#c8c8b4', icon: '💀' },
    { name: 'Орк', hp: 100, atk: 18, exp: 60, color: '#3c6432', icon: '👺' },
    { name: 'Призрак', hp: 50, atk: 14, exp: 45, color: '#6464c8', icon: '👻' },
    { name: 'Дракон', hp: 200, atk: 30, exp: 150, color: '#b42828', icon: '🐉' },
    { name: 'Огненный Элементаль', hp: 80, atk: 20, exp: 70, color: '#ff4422', icon: '🔥' },
    { name: 'Водный Элементаль', hp: 90, atk: 15, exp: 65, color: '#2288ff', icon: '💧' },
    { name: 'Земляной Элементаль', hp: 120, atk: 12, exp: 60, color: '#66aa44', icon: '🪨' },
    { name: 'Воздушный Элементаль', hp: 60, atk: 22, exp: 75, color: '#88ccff', icon: '💨' }
];

// ============================================================
//  BOSS TYPES
// ============================================================
const BOSS_TYPES = [
    { name: '👑 Король Гоблинов', hp: 300, atk: 40, exp: 300, color: '#ff8844', icon: '👑' },
    { name: '👑 Лорд Скелетов', hp: 400, atk: 45, exp: 350, color: '#ccccff', icon: '👑' },
    { name: '👑 Вождь Орков', hp: 500, atk: 50, exp: 400, color: '#44aa44', icon: '👑' },
    { name: '👑 Призрачный Король', hp: 350, atk: 55, exp: 380, color: '#6666ff', icon: '👑' },
    { name: '👑 Дракон-Пожиратель', hp: 700, atk: 60, exp: 500, color: '#ff2266', icon: '👑' }
];
// Portal position object
const PORTAL_POS = { x: CFG.PORTAL_X, y: CFG.PORTAL_Y };
